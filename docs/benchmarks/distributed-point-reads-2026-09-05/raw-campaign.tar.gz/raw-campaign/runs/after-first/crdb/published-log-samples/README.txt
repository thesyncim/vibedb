Last 65536 bytes of 22 structured Cockroach logs from published/server-logs; full published volumes are intentionally excluded.
