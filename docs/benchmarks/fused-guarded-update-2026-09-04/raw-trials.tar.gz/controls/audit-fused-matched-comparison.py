#!/usr/bin/env python3
"""Audit completed matched fused fixtures; never start a fixture or build code."""
import argparse
from collections import Counter
from datetime import datetime
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import statistics
import struct
import subprocess
import sys

sys.dont_write_bytecode = True


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def counters(trials):
    total = Counter()
    for trial in trials:
        for delta in trial['diagnostics']['deltas']:
            total.update(delta['counters'])
    return total


def audit(root, expected_before):
    manifest = json.loads((root / 'manifest.json').read_text())
    assert manifest['status'] == 'complete' and not manifest.get('active_run')
    assert manifest['refs']['before'].startswith(expected_before)
    assert manifest['refs']['before'] != manifest['refs']['after']
    assert manifest['orders'] == {'before-first': ['before', 'after', 'crdb'],
                                  'after-first': ['crdb', 'after', 'before']}
    assert not manifest['profiling']
    expected_limits = {'NanoCpus': 12000000000, 'Memory': 25769803776,
                       'MemorySwap': 25769803776}
    assert manifest['limits'] == expected_limits
    assert [(r['order'], r['arm']) for r in manifest['runs']] == [
        (order, arm) for order, arms in manifest['orders'].items() for arm in arms]
    assert len({r['container'] for r in manifest['runs']}) == 6
    assert len({r['volume'] for r in manifest['runs']}) == 6
    spec = importlib.util.spec_from_file_location(
        'archived_validator', root / 'controls/summarize-crdb-sql.py')
    validator = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(validator)
    reports, sources, locality, updates, health, snapshots = {}, [], [], [], {}, []
    common = None
    for run in manifest['runs']:
        order, arm = run['order'], run['arm']
        relative = Path('baseline-c1-c8') / order / arm
        path = root / relative / 'report.json'
        report, count = validator.load(path, 'cockroachdb' if arm == 'crdb' else 'vibedb')
        reports[order, arm] = report
        config = validator.workload_config(report['config'])
        common = config if common is None else common
        assert config == common
        assert report['config']['PhysicalNodes'] == 3
        assert report['config']['EndpointCount'] == 1
        assert report['status'] == 'complete' and len(report['results']) == 20
        assert count == 25600
        assert all(t['verified'] and t['errors'] == 0 for t in report['results'])
        assert run['status'] == 'completed' and run['client_exit_code'] == 0
        assert not run['errors'] and run['setup']['exit_code'] == 0
        assert run['observed_limits'] == expected_limits
        assert path.read_bytes() == (path.parent / 'raw/report.json').read_bytes()
        assert json.loads((path.parent / 'run.json').read_text()) == run
        assert run['engine'] == ('crdb' if arm == 'crdb' else 'candidate')
        if arm != 'crdb':
            assert run['revision'] == manifest['refs'][arm]
        counts = ({'vibedb': 0, 'vibedb_shard': 0, 'vibedb_gateway': 0, 'cockroach': 3}
                  if arm == 'crdb' else
                  {'vibedb': 1, 'vibedb_shard': 3, 'vibedb_gateway': 0, 'cockroach': 0})
        assert run['process_counts'] == run['process_counts_after'] == counts
        for stage in ['before', 'after']:
            inspection = json.loads((path.parent / f'docker-inspect-{stage}.json').read_text())[0]
            assert {k: inspection['HostConfig'][k] for k in expected_limits} == expected_limits
            assert inspection['Image'] == manifest['images']['runtime']['Id']
        platform = (path.parent / 'ready-platform.txt').read_text().strip()
        assert platform.startswith('Linux ') and 'aarch64' in platform
        sources.append({'order': order, 'arm': arm, 'revision': run['revision'],
                        'report': (relative / 'report.json').as_posix(),
                        'sha256': digest(path), 'version': report['version'],
                        'trials': 20, 'samples': count, 'sql_errors': 0,
                        'platform': platform, 'process_counts': counts,
                        'forced_shutdown': run['forced_shutdown'],
                        'server_exit_codes': run['server_exit_codes']})
        if arm == 'crdb':
            continue
        assert report['config']['DiagnosticMode'] == 'signal-acknowledged-snapshots'
        files = list((path.parent / 'diagnostics').glob('*.json'))
        assert len(files) == 120
        snapshots.extend(files)
        for category, trials in [('reads', [t for t in report['results'] if t['workload'] != 'update_existing']),
                                 ('updates', [t for t in report['results'] if t['workload'] == 'update_existing'])]:
            totals = counters(trials)
            locality.append({'order': order, 'arm': arm, 'class': category,
                             'successful_operations': sum(t['operations'] for t in trials),
                             'counters': dict(totals)})
        for clients in [1, 8]:
            trials = [t for t in report['results'] if t['workload'] == 'update_existing' and t['clients'] == clients]
            totals = counters(trials)
            updates.append({'order': order, 'arm': arm, 'clients': clients,
                            'successful_updates': 4000, 'counters': dict(totals),
                            'cluster_barriers_per_update': totals['observed_append_barriers'] / 4000})
        log = path.parent / 'candidate-server.log'
        lines = log.read_text().splitlines()
        relevant = [(i + 1, line) for i, line in enumerate(lines)
                    if line.startswith('gateway: replica health')]
        health[order + '/' + arm] = {
            'path': (relative / 'candidate-server.log').as_posix(), 'sha256': digest(log),
            'publication_log_lines': sum('published' in line for _, line in relevant),
            'configuration_warning_lines': [i for i, line in relevant if 'invalid replica health controller configuration' in line],
            'ineligible_replacement_log_lines': sum('no eligible replica replacement' in line for _, line in relevant)}
    assert len(snapshots) == 480
    expected_config = {'Rows': 1024, 'Operations': 2000, 'ScanOperations': 200,
                       'Warmup': 100, 'Repetitions': 2, 'Clients': '1,8',
                       'Tables': ['rf3_sql_bench'], 'EndpointCount': 1}
    assert all(common[k] == v for k, v in expected_config.items())
    build_settings = {}
    for name, sha in manifest['build_binary_sha256'].items():
        path = root / 'bin' / name
        assert digest(path) == sha
        with path.open('rb') as stream:
            header = stream.read(20)
        assert header[:6] == b'\x7fELF\x02\x01'
        assert struct.unpack('<H', header[18:20])[0] == 183
        if name == 'cockroach':
            continue
        actual = subprocess.check_output(['go', 'version', '-m', str(path)], text=True).strip()
        assert actual == manifest['vibedb_build_metadata'][name]
        settings = dict(re.findall(r'\tbuild\t([^=\s]+)=(.*)', actual))
        for key, value in [('GOOS', 'linux'), ('GOARCH', 'arm64'), ('GOEXPERIMENT', 'simd'),
                           ('CGO_ENABLED', '0'), ('vcs.modified', 'false')]:
            assert settings[key] == value
        revision = (manifest['source']['client']['revision'] if name == 'rf3-sqlbench' else
                    manifest['refs']['before' if name.startswith('parent-') else 'after'])
        assert settings['vcs.revision'] == revision
        build_settings[name] = settings
    for arm, prefix in [('before', 'parent'), ('after', 'candidate')]:
        for name, sha in manifest['fixture_binary_sha256'][arm].items():
            assert digest(root / (arm + '-bin') / name) == sha
            original = name.replace('candidate-', prefix + '-', 1) if name.startswith('candidate-') else name
            assert sha == manifest['build_binary_sha256'][original]
    assert manifest['fixture_binary_sha256']['crdb'] == manifest['build_binary_sha256']
    for name, sha in manifest['control_sha256'].items():
        assert digest(root / 'controls' / name) == sha
    assert digest(root / 'before-after.patch') == manifest['before_after_patch_sha256']
    assert all(not info['dirty'] and not info['status'] for info in manifest['source'].values())
    assert all(image['Os'] == 'linux' and image['Architecture'] == 'arm64' for image in manifest['images'].values())
    tables, aggregate = {}, {}
    for order in manifest['orders']:
        rows = []
        for workload in common['Workloads']:
            for clients in [1, 8]:
                values = {}
                for arm in ['before', 'after', 'crdb']:
                    trials = [t for t in reports[order, arm]['results'] if (t['workload'], t['clients']) == (workload, clients)]
                    assert len(trials) == 2
                    values[arm] = {'ops_s': statistics.median(t['successful_ops_per_second'] for t in trials),
                                   'p99_ms': statistics.median(t['p99_ns'] for t in trials) / 1e6}
                row = {'workload': workload, 'clients': clients, 'arms': values}
                for base in ['before', 'crdb']:
                    row['throughput_vs_' + base] = values['after']['ops_s'] / values[base]['ops_s']
                    row['p99_vs_' + base] = values['after']['p99_ms'] / values[base]['p99_ms']
                rows.append(row)
        tables[order] = rows
        aggregate[order] = {
            'geomean_vs_before': math.exp(statistics.mean(math.log(r['throughput_vs_before']) for r in rows)),
            'geomean_vs_crdb': math.exp(statistics.mean(math.log(r['throughput_vs_crdb']) for r in rows)),
            'throughput_regressions_over_5pct': [r for r in rows if r['throughput_vs_before'] < .95],
            'p99_regressions_over_10pct': [r for r in rows if r['p99_vs_before'] > 1.1]}
    return {'schema': 'vibedb.matched-fused-audit/1', 'evidence_directory': root.name,
            'refs': manifest['refs'], 'source': manifest['source'], 'config': common,
            'orders': manifest['orders'], 'limits': expected_limits, 'sources': sources,
            'build_settings': build_settings, 'all_actual_binaries_elf64_aarch64': True,
            'build_binary_sha256': manifest['build_binary_sha256'],
            'fixture_binary_sha256': manifest['fixture_binary_sha256'],
            'control_sha256': manifest['control_sha256'],
            'before_after_patch_sha256': manifest['before_after_patch_sha256'],
            'before_after_patch_files': re.findall(r'^diff --git a/(.+) b/.+$', (root / 'before-after.patch').read_text(), re.M),
            'counts': {'fixtures': 6, 'trials': 120, 'samples': 153600, 'sql_errors': 0,
                       'diagnostic_snapshots': 480, 'warmup_operations': 12000,
                       'summed_trial_seconds': sum(t['elapsed_ns'] for r in reports.values() for t in r['results']) / 1e9,
                       'campaign_wall_seconds': (datetime.fromisoformat(manifest['finished_utc']) - datetime.fromisoformat(manifest['started_utc'])).total_seconds()},
            'per_order': aggregate, 'tables': tables, 'locality': locality,
            'updates': updates, 'health_log_evidence': health,
            'qualification': 'Short diagnostic only; do not pool localities or claim full promotion, multigroup/scaling qualification, sustained checkpoint performance or the full 2x CRDB objective.',
            'excluded_other_campaigns': True}


def markdown(data):
    lines = [f"Matched fused audit: before `{data['refs']['before']}`, after `{data['refs']['after']}`.", '',
             '**120 verified trials, 153,600 samples and 480 diagnostic snapshots validated; zero SQL errors.** Only this campaign contributes samples.', '',
             'Actual binaries are ELF64 ARM64; both VibeDB builds and the shared client have verified Linux/ARM64/SIMD build settings and correct clean revisions. CRDB is the stock Linux ARM64 binary. Both VibeDB arms have three fused nodes, identical diagnostics and one shared client. Resource ceilings: 12 CPUs / 24 GiB, swap disabled, including the client.', '',
             'One table, 1,024 rows, C1/C8, two repetitions. Entries are medians of two trial summaries per cell; p99 is milliseconds. Equal-weight geomeans use ten cells within each ordering. **Do not pool the orderings or attribute gains to code when request locality differs.**', '']
    for order, rows in data['tables'].items():
        rates = data['per_order'][order]
        lines += [f"**{order}: after/before {rates['geomean_vs_before']:.6f}×; after/CRDB {rates['geomean_vs_crdb']:.6f}×.**", '',
                  '| Workload | C | Before ops/s | After ops/s | CRDB ops/s | A/B | A/R | Before p99 | After p99 | CRDB p99 | A/B p99 | A/R p99 |',
                  '|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
        for row in rows:
            b, a, c = [row['arms'][arm] for arm in ['before', 'after', 'crdb']]
            values = [b['ops_s'], a['ops_s'], c['ops_s'], row['throughput_vs_before'], row['throughput_vs_crdb'], b['p99_ms'], a['p99_ms'], c['p99_ms'], row['p99_vs_before'], row['p99_vs_crdb']]
            lines.append(f"| {row['workload']} | {row['clients']} | " + ' | '.join(f'{v:.3f}' for v in values) + ' |')
        lines += ['', f"Cells exceeding 5% throughput loss: {len(rates['throughput_regressions_over_5pct'])}; exceeding 10% p99 increase: {len(rates['p99_regressions_over_10pct'])}.", '']
    lines += ['**Locality and counters:** totals across three nodes and both repetitions include background/control activity between snapshots.', '',
              '| Order | Arm | Work | Successes | Local calls | Remote calls | Semantic SQL | SQL encodes |',
              '|---|---|---|---:|---:|---:|---:|---:|']
    for row in data['locality']:
        c = row['counters']
        lines.append(f"| {row['order']} | {row['arm']} | {row['class']} | {row['successful_operations']} | {c['gateway_local_calls']} | {c['gateway_remote_calls']} | {c['gateway_semantic_sql_calls']} | {c['gateway_sql_request_encodings']} |")
    lines += ['', '**Update diagnostics:** 4,000 successful updates per row. Barriers are cluster totals, not per-node counts or direct fsync timings.', '',
              '| Order | Arm | C | Barriers/update | Multi-group/total waves | Checkpoint count | Checkpoint wait ns | Checkpoint service ns |',
              '|---|---|---:|---:|---:|---:|---:|---:|']
    for row in data['updates']:
        c = row['counters']
        lines.append(f"| {row['order']} | {row['arm']} | {row['clients']} | {row['cluster_barriers_per_update']:.4f} | {c['multi_group_waves']}/{c['ready_waves']} | {c['checkpoint_queue_submissions']} | {c['checkpoint_queue_wait_ns']} | {c['checkpoint_service_ns']} |")
    lines += ['', '**Runtime and cleanup qualifications:**', '']
    for label, health in data['health_log_evidence'].items():
        failures = sum(r['counters']['native_failed'] for r in data['locality'] if r['order'] + '/' + r['arm'] == label)
        lines.append(f"- {label}: {health['publication_log_lines']} retained health publication lines; {len(health['configuration_warning_lines'])} configuration warning lines; {health['ineligible_replacement_log_lines']} ineligible-replacement lines; native connection-service failure delta {failures}.")
    for source in data['sources']:
        if source['forced_shutdown'] or any(code != 0 for code in source['server_exit_codes']):
            lines.append(f"- {source['order']}/{source['arm']}: post-measurement forced shutdown={source['forced_shutdown']}, server exit codes={source['server_exit_codes']}. This cleanup is not a durability or recovery qualification.")
    lines += ['', 'Controller logs are retained text counts, not deduplicated timed rates; untimestamped warnings do not establish a causal latency impact. Zero SQL errors does not mean every runtime counter was error-free. Counter details remain in JSON.', '',
              data['qualification'] + ' The 200-sample scan/group trials have limited p99 resolution. Preserve failures and partial campaigns separately; no earlier timings are included.', '', '**Raw sources:**', '']
    lines += [f"- [{s['order']}/{s['arm']}]({s['report']}) — 20 trials / 25,600 samples; SHA256 in JSON." for s in data['sources']]
    lines += ['', 'Archive only approved report/diagnostic files and controls using an explicit allowlist. Preserve exact bytes and relative paths. Exclude private keys, node data/manifests, supervisor configuration and duplicate raw files.', '']
    return '\n'.join(lines)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path)
    parser.add_argument('--expected-before', required=True)
    args = parser.parse_args()
    targets = [args.root / 'audit-summary.json', args.root / 'audit-summary.md']
    assert not any(p.exists() for p in targets), 'refusing to overwrite existing audit outputs'
    result = audit(args.root, args.expected_before)
    targets[0].write_text(json.dumps(result, indent=2) + '\n')
    targets[1].write_text(markdown(result))
    print(json.dumps({'outputs': [str(p) for p in targets], 'counts': result['counts'],
                      'per_order': result['per_order']}, indent=2))
