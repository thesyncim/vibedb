# Current projected-range diagnostic profile

This directory retains a clean detached source tree at `9454ced0d6327f7dc598c04a7f5d5c0265d9987c`, four Linux/ARM64 binaries built with Go 1.27.0 and `GOEXPERIMENT=simd`, the exact fixture invocation, and raw CPU/trace evidence. The run is diagnostic only: it has one internal VibeDB `candidate` arm, no before/after arm, no CRDB arm, no cross-machine claim, and no throughput or latency result.

## Build

Run from `/private/tmp/vibedb-point-range-profile/src` with the detached worktree clean:

```sh
GOTOOLCHAIN=local GOOS=linux GOARCH=arm64 CGO_ENABLED=0 GOEXPERIMENT=simd \
GOCACHE=/private/tmp/vibedb-point-range-profile/gocache \
GOMODCACHE=/private/tmp/vibedb-point-range-profile/modcache \
GOPROXY=file:///Users/thesyncim/go/pkg/mod/cache/download GOSUMDB=off \
/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.0.darwin-arm64/bin/go \
build -mod=readonly -trimpath -o /private/tmp/vibedb-point-range-profile/bin/candidate-vibedb ./cmd/vibedb
```

The same command was used for `./cmd/vibedb-shard` to `candidate-vibedb-shard` and `./cmd/vibedb-gateway` to `candidate-vibedb-gateway`; the shared client used the `integration/pgclient` module and `./cmd/rf3-sqlbench` as `rf3-sqlbench`. `provenance.json` records hashes, `file` output, `go version -m`, and source status.

## Profile

Docker must report ARM64. The fixture creates a fresh candidate-only RF3 deployment with three physical VibeDB processes, four logical tables, 3-way replication, and one loopback SQL frontend in the same Linux/ARM64 Docker VM. The workload is `range_64`, 8 clients, 8,192 rows per table, 8 operations, 10,000 scan operations, 1,000 warmup operations, and one repetition. Resource ceilings are 12 CPUs and 24 GiB with swap disabled.

```sh
PYTHONDONTWRITEBYTECODE=1 python3 /private/tmp/vibedb-point-range-profile/run_profile.py \
  /private/tmp/vibedb-point-range-profile/range_64 \
  --workload range_64 --clients 8 --rows 8192 --operations 8 \
  --scans 10000 --warmup 1000 --repetitions 1 \
  --groups 4 --physical-nodes 3 --cpus 12 --memory 24g
```

The launcher injects `VIBEDB_PROFILE_DIRECTORY=/evidence` and
`VIBEDB_PROFILE_DURATION=90s` into the candidate server process. The existing
profile hook starts at server launch, so startup/setup is included. It emits
CPU pprof and execution trace files; it does not emit a heap/allocation
profile. Allocation targets can therefore only be discussed from source and
CPU symbols, with no allocation count claim.

## Verification and summaries

After a completed or failed attempt, the fixture retains manifests, logs,
topology inventories, report, and raw profile files under `range_64/`. The
current source validator is used by the fixture for the report/oracle checks.
`verify_profile.py` and `summarize_profiles.py` are intentionally separate
read-only post-processing helpers. A report status of `complete` and all
verified trials are required before calling the profile internally valid;
profile timings remain diagnostic and are not benchmark results.

The source paths to inspect alongside `profile-top/*.txt` are
`store/durable/store_file_scan.go:rangePrimaryGraphBuffer`,
`internal/storeio/primary_graph_cursor.go:PrimaryGraphCursor.VisitInlineDecoded`,
and `query/file_execute.go:fileBatch.data`. These are the projected-range
materialization/evaluation targets selected for the next production review.
