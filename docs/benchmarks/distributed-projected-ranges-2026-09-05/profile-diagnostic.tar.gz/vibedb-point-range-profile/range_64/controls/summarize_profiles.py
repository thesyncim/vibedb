#!/usr/bin/env python3
"""Render CPU pprof top tables and source-symbol allocation targets."""

import hashlib
import json
from pathlib import Path
import subprocess
import sys


ROOT = Path("/private/tmp/vibedb-point-range-profile")
BIN = ROOT / "bin/candidate-vibedb-shard"
GO = Path("/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.0.darwin-arm64/bin/go")


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main(argv=None):
    evidence = Path(argv[0]) if argv else ROOT / "range_64"
    raw = evidence / "multigroup-3n-uniform/profile/candidate/raw"
    out = evidence / "profile-top"
    out.mkdir(mode=0o700, exist_ok=True)
    records = []
    for profile in sorted(raw.glob("*.cpu.pprof")):
        command = [str(GO), "tool", "pprof", "-top", "-nodecount=40", str(BIN), str(profile)]
        completed = subprocess.run(command, text=True, stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT, check=False)
        summary = out / f"{profile.stem}.txt"
        summary.write_text(completed.stdout)
        records.append({
            "profile": str(profile.relative_to(evidence)),
            "profile_sha256": sha256(profile),
            "summary": str(summary.relative_to(evidence)),
            "command": command,
            "exit_code": completed.returncode,
        })
    index = out / "index.json"
    index.write_text(json.dumps({
        "binary": str(BIN),
        "binary_sha256": sha256(BIN),
        "profiles": records,
        "diagnostic_only": True,
        "timings_are_not_benchmark_results": True,
        "allocation_note": "CPU symbols only; this hook emitted no heap/allocation profile.",
    }, indent=2) + "\n")
    print(json.dumps({"summary_index": str(index), "profiles": records}, indent=2))
    return 0 if records and all(record["exit_code"] == 0 for record in records) else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
