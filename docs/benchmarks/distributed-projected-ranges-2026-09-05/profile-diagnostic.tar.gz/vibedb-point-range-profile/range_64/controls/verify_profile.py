#!/usr/bin/env python3
"""Re-run the current strict RF3 report/oracle validator on profile output."""

from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import sys


ROOT = Path("/private/tmp/vibedb-point-range-profile")
SOURCE_VALIDATOR = ROOT / "src/scripts/bench/summarize-crdb-sql.py"
REPORT = ROOT / "range_64/multigroup-3n-uniform/profile/candidate/report.json"
OUTPUT = ROOT / "range_64/profile-verification.json"


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main(argv=None):
    report = Path(argv[0]) if argv else REPORT
    output = Path(argv[1]) if argv and len(argv) > 1 else OUTPUT
    spec = importlib.util.spec_from_file_location("profile_validator", SOURCE_VALIDATOR)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {SOURCE_VALIDATOR}")
    validator = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(validator)
    loaded, samples = validator.load(report, "vibedb")
    result = {
        "status": "verified" if loaded.get("status") == "complete" and not loaded.get("verification_error") else "failed",
        "report": str(report),
        "report_sha256": sha256(report),
        "report_status": loaded.get("status"),
        "report_verification_error": loaded.get("verification_error"),
        "verified_trials": sum(bool(trial.get("verified")) for trial in loaded.get("results", [])),
        "trial_count": len(loaded.get("results", [])),
        "samples_checked": samples,
        "validator_source": str(SOURCE_VALIDATOR),
        "validator_source_sha256": sha256(SOURCE_VALIDATOR),
        "diagnostic_only": True,
        "timings_are_not_benchmark_results": True,
        "verified_utc": datetime.now(timezone.utc).isoformat(),
    }
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    return 0 if result["status"] == "verified" else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv[1:]))
    except Exception as exc:
        print(f"verify_profile: {exc}", file=sys.stderr)
        raise SystemExit(2)
