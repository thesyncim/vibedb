#!/usr/bin/env python3
"""Capture one current-source RF3 range-read CPU/trace diagnostic.

This deliberately reuses the reviewed fused-node fixture.  It runs only the
candidate arm internally, because this artifact is a materialization profile,
not a before/after timing campaign.  The fixture still performs its normal
setup, topology, report, and oracle validation.
"""

from datetime import datetime, timezone
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys


ROOT = Path("/private/tmp/vibedb-point-range-profile")
SOURCE = ROOT / "src"
BIN = ROOT / "bin"
FIXTURE_PATH = SOURCE / "scripts/bench/run-fused-node-comparison.py"
VALIDATOR_PATH = SOURCE / "scripts/bench/summarize-crdb-sql.py"
REVISION = "9454ced0d6327f7dc598c04a7f5d5c0265d9987c"
PROFILE_ENV = {
    "VIBEDB_PROFILE_DIRECTORY": "/evidence",
    "VIBEDB_PROFILE_DURATION": "90s",
}
WORKLOADS = ("point_hit", "point_miss", "range_64")


def load_fixture():
    spec = importlib.util.spec_from_file_location("point_range_profile_fixture", FIXTURE_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load fixture {FIXTURE_PATH}")
    fixture = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(fixture)
    return fixture


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def source_info():
    fixture = load_fixture()
    info = fixture.git_info(SOURCE)
    patch = info.pop("patch")
    info["patch_sha256"] = hashlib.sha256(patch).hexdigest()
    return info


def binary_hashes():
    if not BIN.is_dir():
        return {}
    return {
        path.name: {"sha256": sha256(path), "bytes": path.stat().st_size}
        for path in sorted(BIN.iterdir()) if path.is_file()
    }


def profile_artifacts(run_dir):
    artifacts = []
    raw = run_dir / "raw"
    if not raw.is_dir():
        return artifacts
    for path in sorted(raw.rglob("*")):
        if path.is_file() and (path.name.endswith(".cpu.pprof") or path.name.endswith(".trace")):
            artifacts.append({
                "path": str(path.relative_to(run_dir)),
                "sha256": sha256(path),
                "bytes": path.stat().st_size,
            })
    return artifacts


def now():
    return datetime.now(timezone.utc).isoformat()


def build_fixture_args(fixture, config, output):
    return fixture.parser().parse_args([
        str(output),
        "--repo", str(SOURCE),
        "--client-source", str(SOURCE),
        "--candidate-ref", REVISION,
        "--matrix", "all",
        "--groups", str(config.groups),
        "--physical-nodes", str(config.physical_nodes),
        "--distributions", "uniform",
        "--endpoint-modes", "single",
        "--multigroup-workloads", config.workload,
        "--multigroup-clients", config.clients,
        "--rows", str(config.rows),
        "--operations", str(config.operations),
        "--scans", str(config.scans),
        "--warmup", str(config.warmup),
        "--repetitions", str(config.repetitions),
        "--cpus", config.cpus,
        "--memory", config.memory,
        "--order", "candidate-first",
        "--no-include-crdb",
        "--vibedb-sql-ports", "5432",
    ])


def parser():
    value = argparse.ArgumentParser(description=__doc__)
    value.add_argument("output", type=Path,
                       help="new absolute evidence directory")
    value.add_argument("--workload", choices=WORKLOADS, default="range_64")
    value.add_argument("--clients", default="8")
    value.add_argument("--rows", type=int, default=8192)
    value.add_argument("--operations", type=int, default=8)
    value.add_argument("--scans", type=int, default=10000)
    value.add_argument("--warmup", type=int, default=1000)
    value.add_argument("--repetitions", type=int, default=1)
    value.add_argument("--groups", type=int, default=4)
    value.add_argument("--physical-nodes", type=int, default=3)
    value.add_argument("--cpus", default="12")
    value.add_argument("--memory", default="24g")
    return value


def manifest_for(config, output, fixture, arch=None, docker_host=None, image=None):
    return {
        "schema": "vibedb.point-range-profile/1",
        "started_utc": now(),
        "status": "preparing",
        "diagnostic_only": True,
        "timings_are_not_benchmark_results": True,
        "startup_included": True,
        "startup_exclusion": (
            "The existing processprofile hook starts with the server and has no delayed-start option; "
            "startup/setup remains in CPU and trace artifacts."
        ),
        "source": {"revision": REVISION, "worktree": str(SOURCE), "git": source_info()},
        "binaries": binary_hashes(),
        "workload": {
            "workload": config.workload,
            "clients": config.clients,
            "rows_per_table": config.rows,
            "operations": config.operations,
            "scans": config.scans,
            "warmup": config.warmup,
            "repetitions": config.repetitions,
            "groups": config.groups,
            "physical_nodes": config.physical_nodes,
        },
        "topology": {
            "replication_factor": 3,
            "single_host_fixture": True,
            "internal_fixture_engine": "candidate",
            "comparison_arm": "none; candidate-only diagnostic",
            "publication": False,
            "horizontal_multimachine_scaling": False,
        },
        "limits": {"cpus": config.cpus, "memory": config.memory, "memory_swap": config.memory},
        "profile": {
            **PROFILE_ENV,
            "recording": "CPU pprof plus execution trace from inherited VibeDB server processes",
            "heap_or_allocation_profile": False,
            "allocation_evidence": "source/CPU targets only; no allocation counts are emitted by this hook",
        },
        "docker": {
            "architecture": arch,
            "host": docker_host,
            "runtime_image": image or fixture.RUNTIME,
        },
        "controls": {},
    }


def main(argv=None):
    outer = parser().parse_args(argv)
    fixture = load_fixture()
    output = fixture.require_new_directory(outer.output)
    fixture.COMMAND_LOG = output / "control-commands.jsonl"
    controls = output / "controls"
    controls.mkdir(mode=0o700)
    config = outer
    fixture_args = build_fixture_args(fixture, config, output)
    fixture_args.validator_path = VALIDATOR_PATH

    manifest = manifest_for(config, output, fixture)
    for path in (Path(__file__), FIXTURE_PATH, VALIDATOR_PATH):
        copied = controls / path.name
        shutil.copy2(path, copied)
        manifest["controls"][path.name] = {
            "path": str(copied.relative_to(output)),
            "sha256": sha256(copied),
        }
    fixture.write_json(output / "manifest.json", manifest)

    run_dir = None
    try:
        arch = fixture.docker_architecture()
        if arch != "arm64":
            raise fixture.RunnerError(f"diagnostic profile requires Docker arm64, got {arch}")
        image = fixture.ensure_image(fixture.RUNTIME)
        fixture_args.runtime_image_id = image["Id"]
        manifest["docker"].update({
            "architecture": arch,
            "host": fixture.docker_json(["docker", "info", "--format", "{{json .}}"]),
            "runtime_image": image,
        })
        manifest["status"] = "ready-to-run"
        manifest["binaries"] = binary_hashes()
        fixture.write_json(output / "manifest.json", manifest)

        cells = [cell for cell in fixture.cell_matrix(fixture_args) if cell["kind"] == "multigroup"]
        if len(cells) != 1:
            raise fixture.RunnerError(f"expected one multigroup profile cell, got {len(cells)}")
        cell = cells[0]
        run_dir = output / cell["id"] / "profile" / "candidate"
        schema = fixture.schema_files(run_dir, cell["tables"])
        manifest["cell"] = cell
        manifest["active_run"] = {
            "fixture_engine": "candidate",
            "evidence_path": str(run_dir.relative_to(output)),
        }
        fixture.write_json(output / "manifest.json", manifest)

        original_popen = fixture.subprocess.Popen

        def profile_popen(command, *positional, **keyword):
            if (isinstance(command, list) and len(command) > 4 and
                    command[:2] == ["docker", "exec"] and
                    command[3] == "/bench/candidate-vibedb" and command[4] == "cluster"):
                command = command[:2] + [
                    "-e", f"VIBEDB_PROFILE_DIRECTORY={PROFILE_ENV['VIBEDB_PROFILE_DIRECTORY']}",
                    "-e", f"VIBEDB_PROFILE_DURATION={PROFILE_ENV['VIBEDB_PROFILE_DURATION']}",
                ] + command[2:]
                manifest["server_command"] = command
                manifest["status"] = "profiling"
                fixture.write_json(output / "manifest.json", manifest)
            return original_popen(command, *positional, **keyword)

        fixture.subprocess.Popen = profile_popen
        try:
            result = fixture.run_engine(fixture_args, cell, "candidate", "profile", BIN,
                                        run_dir, schema, arch)
        finally:
            fixture.subprocess.Popen = original_popen

        result["diagnostic_only"] = True
        result["timings_are_not_benchmark_results"] = True
        result["startup_included"] = True
        manifest["run"] = result
        manifest["profile_artifacts"] = profile_artifacts(run_dir)
        manifest.pop("active_run", None)
        manifest["status"] = "complete" if result.get("status") == "completed" else "failed"
        manifest["finished_utc"] = now()
        fixture.write_json(run_dir / "run.json", result)
        fixture.write_json(output / "manifest.json", manifest)
        print(json.dumps({"status": manifest["status"],
                          "profile_artifacts": manifest["profile_artifacts"]}, indent=2))
        return 0 if manifest["status"] == "complete" else 1
    except BaseException as exc:
        # Keep the preparation/build/image/cell/server command metadata on every
        # late failure.  A diagnostic failure must remain reviewable.
        manifest["status"] = "failed"
        manifest["fatal_error"] = f"{type(exc).__name__}: {exc}"
        if run_dir is not None:
            manifest["profile_artifacts"] = profile_artifacts(run_dir)
        manifest["finished_utc"] = now()
        fixture.write_json(output / "manifest.json", manifest)
        raise


if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv[1:]))
    except Exception as exc:
        print(f"run_profile: {exc}", file=sys.stderr)
        raise SystemExit(2)
