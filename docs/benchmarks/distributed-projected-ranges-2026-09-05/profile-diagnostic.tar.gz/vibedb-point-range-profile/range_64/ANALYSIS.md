# Range-read profile findings

The candidate-only RF3 fixture completed its `range_64` report with 10,000
verified samples. The three shard CPU profiles were 17.81–17.82 seconds long
and retain matching execution traces. The retained profile set is six files:
216,026 bytes of CPU pprof and 25,053,265 bytes of trace data (25,269,291
bytes total). The per-shard CPU sample totals are 13.75s, 5.04s, and 6.80s;
these are profiler sample durations, not throughput or latency measurements.
The run is diagnostic only.

The exact fixture limits were 12 Docker CPUs (`NanoCpus=12,000,000,000`),
24 GiB memory (`Memory=25,769,803,776`), and the same value for
`MemorySwap` (swap disabled). It used three serving shard processes, four
logical tables, RF3, one loopback SQL endpoint, and the candidate binary only.

The profile hook starts when each server starts, so startup, table setup, and
background RF3 checkpoint work remain in the samples. The broad top tables are
therefore dominated by Linux syscalls, futexes, raft ready/apply loops, and
checkpoint/fsync work. The focused pprof views still show the current read
materialization path in the serving shards:

* `query.(*plan).runFileSnapshotBatched` and `query.(*plan).runFileSmall` are
  the principal query-side callers.
* `store/durable.(*Snapshot).rangePrimaryGraphBuffer` contributes about 2.7%
  to 4.9% cumulative in the three focused shard views, and
  `internal/storeio.(*PrimaryGraphCursor).VisitInlineDecoded` about 2.4% to
  4.6%. These symbols confirm that the compact primary range drain is active.
* `query.(*fileSmallScan).appendRow` and
  `query.(*plan).appendFileRawCoveredResult` are visible in the same path.
  `query/file_execute.go:fileBatch.data` is the retained byte buffer consumed
  by these projection paths; its warm reuse and batch-to-arena handoff are the
  allocation targets for the production review.

The CPU-only allocation indicators are `runtime.mallocgc`, `runtime.growslice`,
`runtime.memmove`, and `runtime.memclrNoHeapPointers`, alongside
`fileSmallScan.appendRow`, `appendFileRawCoveredResult`, and
`vibejson.AppendCanonicalize`. The existing hook emits no heap or allocation
profile, so these are targets for a later allocation run rather than allocation
counts. `runtime.mallocgc` reached 4.4% cumulative in the strongest focused
shard view; the exact per-shard tables are retained under `profile-top/`.

The next review should preserve the projected scalar range path while checking
whether batch bytes and scalar arena growth can avoid the remaining
`mallocgc`/`growslice`/`memmove` work. Any before/after or point-hit/miss
comparison belongs to a separately coordinated matched campaign.
