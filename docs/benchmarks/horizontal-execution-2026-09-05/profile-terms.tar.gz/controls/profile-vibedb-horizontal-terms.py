import hashlib, importlib.util, json, os, shutil, subprocess
from pathlib import Path
ROOT=Path('/private/tmp/vibedb-horizontal')
SOURCE=Path('/private/tmp/vibedb-horizontal-terms-evidence')
DEST=Path('/private/tmp/vibedb-horizontal-profile-terms')
spec=importlib.util.spec_from_file_location('fixture', ROOT/'scripts/bench/run-fused-node-comparison.py')
f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
args=f.parser().parse_args([str(DEST),'--candidate-ref','b5c3dcaa','--matrix','all','--groups','16','--physical-nodes','3','--distributions','uniform','--endpoint-modes','single','--multigroup-workloads','mixed_uniform','--multigroup-clients','8','--rows','512','--operations','16000','--warmup','500','--repetitions','1'])
f.require_new_directory(DEST)
f.COMMAND_LOG=DEST/'control-commands.jsonl'
controls=DEST/'controls';controls.mkdir()
for p in [Path(__file__),ROOT/'scripts/bench/run-fused-node-comparison.py',ROOT/'scripts/bench/summarize-crdb-sql.py']:
 shutil.copy2(p,controls/p.name)
args.validator_path=controls/'summarize-crdb-sql.py'
m=json.load(open(SOURCE/'manifest.json'))
args.runtime_image_id=m['images']['runtime']['Id']
manifest={'profiling':True,'timings_are_not_benchmark_results':True,'source_manifest':str(SOURCE/'manifest.json'),'revision':m['refs']['after'],'binary_sha256':f.binary_hashes(SOURCE/'after-bin'),'profile_environment':{'VIBEDB_PROFILE_DIRECTORY':'/evidence','VIBEDB_PROFILE_DURATION':'120s'},'source_build_metadata':m['vibedb_build_metadata']}
original_popen=subprocess.Popen
def profile_popen(command,*a,**kw):
 if isinstance(command,list) and command[:2]==['docker','exec'] and len(command)>4 and command[3]=='/bench/candidate-vibedb' and command[4]=='cluster':
  command=command[:2]+['-e','VIBEDB_PROFILE_DIRECTORY=/evidence','-e','VIBEDB_PROFILE_DURATION=120s']+command[2:]
  manifest['server_command']=command
  f.write_json(DEST/'manifest.json',manifest)
 return original_popen(command,*a,**kw)
subprocess.Popen=profile_popen
cell=f.cell_matrix(args)[1]
manifest['cell']=cell
f.write_json(DEST/'manifest.json',manifest)
result=f.run_engine(args,cell,'candidate','profile',SOURCE/'after-bin',DEST,f.schema_files(DEST,cell['tables']),m['docker_architecture'])
manifest['run']=result
f.write_json(DEST/'manifest.json',manifest)
print(result['status'],result['errors'],flush=True)
