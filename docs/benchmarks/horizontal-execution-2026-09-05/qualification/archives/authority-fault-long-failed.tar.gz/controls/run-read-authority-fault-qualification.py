#!/usr/bin/env python3
"""Run a bounded RF3 read-authority fault qualification.

This command is a correctness diagnostic for one Linux, single-host Docker
fixture.  It retains strict SQL/oracle evidence while exercising a process
pause beyond the configured grant and a same-root process restart.  It never
produces a throughput comparison or a CRDB result.
"""

from datetime import datetime, timezone
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import threading
import time


ROOT = Path(__file__).resolve().parents[2]
FIXTURE_PATH = ROOT / "scripts/bench/run-fused-node-comparison.py"
VALIDATOR_PATH = ROOT / "scripts/bench/summarize-crdb-sql.py"
RUNTIME = (
    "golang:1.27-bookworm@sha256:648f440f42a0958804efb24df176f806f9d353b41f1c0627f666428e40310f6b"
)
GOCACHE = Path("/private/tmp/vibedb-horizontal-gocache")
QUARANTINE_SECONDS = 6.11
GRANT_SECONDS = 5.0


def load_fixture():
    spec = importlib.util.spec_from_file_location("vibedb_fault_fixture", FIXTURE_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"could not load fixture {FIXTURE_PATH}")
    fixture = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(fixture)
    return fixture


def utc_now():
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def source_snapshot(fixture, repo, destination, label):
    """Retain all changed bytes, including untracked files, for provenance."""
    info = fixture.git_info(repo)
    summary = {key: value for key, value in info.items() if key != "patch"}
    fixture.write_git_evidence(destination, label, dict(info))
    status_lines = fixture.text_output([
        "git", "-C", str(repo), "status", "--porcelain=v1", "--untracked-files=all",
    ]).splitlines()
    statuses = {line[3:]: line[:2] for line in status_lines if len(line) >= 4}
    changed = sorted(statuses)
    retained = destination / f"source-{label}-files"
    records = []
    for relative in changed:
        path = (repo / relative).resolve()
        record = {"path": relative, "status": statuses[relative]}
        try:
            path.relative_to(repo.resolve())
        except ValueError:
            record["error"] = "changed path resolves outside repository"
            records.append(record)
            continue
        if not path.is_file():
            record["error"] = "changed path is not a regular file"
            records.append(record)
            continue
        content = path.read_bytes()
        record["size"] = len(content)
        record["sha256"] = hashlib.sha256(content).hexdigest()
        target = retained / relative
        target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        target.write_bytes(content)
        records.append(record)
    summary["files"] = records
    summary["file_sha256"] = {
        record["path"]: record["sha256"]
        for record in records if "sha256" in record
    }
    return summary


def source_identity(snapshot):
    return {
        "revision": snapshot.get("revision"),
        "status": snapshot.get("status"),
        "patch_sha256": snapshot.get("patch_sha256"),
        "file_sha256": snapshot.get("file_sha256", {}),
    }


def build_candidate(fixture, repo, destination, arch):
    binaries = destination / "bin"
    binaries.mkdir(mode=0o700)
    env = dict(os.environ, GOOS="linux", GOARCH=arch, CGO_ENABLED="0",
               GOEXPERIMENT="simd", GOCACHE=str(GOCACHE))
    packages = (
        ("candidate-vibedb", repo, "./cmd/vibedb"),
        ("candidate-vibedb-shard", repo, "./cmd/vibedb-shard"),
        ("candidate-vibedb-gateway", repo, "./cmd/vibedb-gateway"),
        ("rf3-sqlbench", repo / "integration/pgclient", "./cmd/rf3-sqlbench"),
    )
    for name, source, package in packages:
        fixture.build_binary(source, package, binaries / name, env)
    metadata = {}
    for executable in sorted(binaries.iterdir()):
        value = fixture.text_output(["go", "version", "-m", executable])
        for setting in ("GOEXPERIMENT=simd", "GOOS=linux", "GOARCH=" + arch):
            if "\tbuild\t" + setting not in value:
                raise fixture.RunnerError(
                    f"{executable.name} is missing required build setting {setting}")
        metadata[executable.name] = value
    return binaries, metadata, env


def json_sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parse_snapshot(path, target):
    value = json.loads(path.read_text())
    if value.get("event") != "snapshot" or value.get("pid") != target["pid"] or value.get("node_id") != target["node_id"]:
        raise RuntimeError(f"diagnostic identity mismatch for node {target['node_id']}")
    if not isinstance(value.get("serial"), int) or value["serial"] < 1:
        raise RuntimeError("diagnostic snapshot has no positive serial")
    return value


def counter(value, name):
    result = value.get(name)
    if not isinstance(result, int):
        raise RuntimeError(f"diagnostic snapshot is missing integer {name}")
    return result


def diagnostics_summary(path):
    records = []
    for candidate in sorted(path.rglob("*.json")) if path.exists() else ():
        try:
            value = json.loads(candidate.read_text())
        except (OSError, UnicodeDecodeError, json.JSONDecodeError):
            continue
        if not isinstance(value, dict) or "read_authority_rounds_started" not in value:
            continue
        records.append({
            "path": str(candidate.relative_to(path)),
            "node_id": value.get("node_id"),
            "pid": value.get("pid"),
            "authority_read_hits": value.get("authority_read_hits"),
            "authority_read_index_fallbacks": value.get("authority_read_index_fallbacks"),
            "read_authority_rounds_started": value.get("read_authority_rounds_started"),
            "read_authority_requests_created": value.get("read_authority_requests_created"),
            "read_authority_grants_accepted": value.get("read_authority_grants_accepted"),
        })
    return records


def authority_proof(records):
    latest = {}
    for record in records:
        node = record.get("node_id") or record.get("path")
        hits = record.get("authority_read_hits")
        rounds = record.get("read_authority_rounds_started")
        if isinstance(hits, int) and isinstance(rounds, int):
            previous = latest.get(node, (0, 0))
            latest[node] = (max(previous[0], hits), max(previous[1], rounds))
    hits = sum(value[0] for value in latest.values())
    rounds = sum(value[1] for value in latest.values())
    return {
        "nodes": len(latest),
        "lifetime_authority_read_hits": hits,
        "lifetime_read_authority_rounds_started": rounds,
        "rounds_amortized": hits > 0 and 0 < rounds < hits,
        "several_rounds": rounds >= 3,
        "basis": "per-node maximum acknowledged diagnostic counters; setup counters may precede workload brackets",
    }


def remote_snapshot(fixture, container, target, destination, label, prior_serial=None):
    """Signal and archive one acknowledged diagnostic snapshot."""
    destination.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    if prior_serial is None:
        prior_serial = 0
    fixture.run(["docker", "exec", container, "kill", "-USR1", str(target["pid"])])
    deadline = time.monotonic() + 10
    temporary = destination.with_suffix(destination.suffix + ".tmp")
    last = None
    while time.monotonic() < deadline:
        copied = fixture.run([
            "docker", "cp", container + ":" + target["path"], temporary,
        ], check=False, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        if copied.returncode == 0:
            try:
                value = parse_snapshot(temporary, target)
                last = value
                if value["serial"] > prior_serial:
                    os.replace(temporary, destination)
                    return value
            except (OSError, json.JSONDecodeError, RuntimeError):
                pass
        time.sleep(0.05)
    temporary.unlink(missing_ok=True)
    raise RuntimeError(
        f"diagnostic acknowledgement did not advance for node {target['node_id']} "
        f"(prior={prior_serial}, last={last})")


def all_snapshots(fixture, container, targets, destination, label, prior=None):
    prior = prior or {}
    values = {}
    for index, target in enumerate(targets):
        path = destination / f"{label}-node{index}.json"
        values[target["node_id"]] = remote_snapshot(
            fixture, container, target, path, label,
            prior.get(target["node_id"], 0))
    return values


def current_serials(fixture, container, targets, destination):
    values = {}
    for index, target in enumerate(targets):
        path = destination / f"current-node{index}.json"
        copied = fixture.run([
            "docker", "cp", container + ":" + target["path"], path,
        ], check=False, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        if copied.returncode == 0:
            try:
                value = parse_snapshot(path, target)
                values[target["node_id"]] = value["serial"]
            except (OSError, json.JSONDecodeError, RuntimeError):
                pass
        path.unlink(missing_ok=True)
    return values


def node_group_incarnations(destination, prefix="ready"):
    result = {}
    root = destination / "published" / prefix
    if not root.exists():
        return result
    for path in sorted(root.rglob("serve-rf3.vibejson")):
        try:
            value = json.loads(path.read_text())
            route = value.get("route", {})
            group = route.get("group_id")
            incarnation = route.get("shard_incarnation")
            parts = path.parts
            node = next((part for part in parts if part.startswith("node-") and part[5:].isdigit()), None)
            if node and isinstance(group, str) and isinstance(incarnation, str):
                result.setdefault(node, {})[group] = incarnation
        except (OSError, UnicodeDecodeError, json.JSONDecodeError):
            continue
    return result


def target_identity(inventory, target, group_incarnations):
    process = None
    for line in inventory.get("processes", {}).get("text", "").splitlines():
        fields = line.split(None, 3)
        if fields and fields[0].isdigit() and int(fields[0]) == target["pid"]:
            process = line
            break
    return {
        "pid": target["pid"],
        "node_id": target["node_id"],
        "executable": target.get("executable"),
        "process_line": process,
        "group_incarnations": group_incarnations,
    }


def exact_candidate_pids(fixture, container, inventory):
    pids = []
    for line in inventory.get("executables", {}).get("text", "").splitlines():
        fields = line.split("\t", 1)
        if len(fields) == 2 and fields[0].isdigit() and fields[1] in {
            "/bench/candidate-vibedb", "/bench/candidate-vibedb-shard",
        }:
            pids.append(fields[0])
    if len(pids) != 4 or not all(pid.isdigit() for pid in pids):
        raise fixture.RunnerError(
            "restart fault requires one candidate supervisor and three candidate shard processes")
    return sorted(pids, key=int)


def copy_markers(fixture, container, destination, label, nodes=3, groups=4):
    records = []
    for node in range(1, nodes + 1):
        for group in range(groups):
            remote = f"/data/vibe/node-{node}/group-{group}/read-authority.state.vibejson"
            local = destination / f"{label}-node{node}-group{group}-read-authority.state.vibejson"
            copied = fixture.run(["docker", "cp", container + ":" + remote, local],
                                 check=False, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            record = {"remote": remote, "path": str(local), "exit_code": copied.returncode}
            if copied.returncode == 0:
                try:
                    value = json.loads(local.read_text())
                    record.update({
                        "enabled": value.get("enabled"),
                        "feature_version": value.get("feature_version"),
                        "policy_version": value.get("policy_version"),
                        "policy_digest": value.get("policy_digest"),
                        "sha256": json_sha256(local),
                    })
                except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
                    record["error"] = str(exc)
            records.append(record)
    return records


def capture_restart_diagnostics(fixture, container, targets, destination, label):
    values = {}
    for index, target in enumerate(targets):
        path = destination / f"{label}-node{index}.json"
        # The new process has a fresh counter stream, so the serial can start
        # at one.  Poll for the first acknowledged snapshot without assuming a
        # serial relationship to the pre-crash incarnation.
        values[target["node_id"]] = remote_snapshot(
            fixture, container, target, path, label, prior_serial=0)
    return values


def wait_processes(processes):
    for process in processes:
        if process.poll() is None:
            try:
                process.wait(timeout=20)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=5)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path, help="new absolute evidence directory")
    parser.add_argument("--repo", type=Path, default=ROOT)
    parser.add_argument("--operations", type=int, default=50000)
    parser.add_argument("--scans", type=int, default=500)
    parser.add_argument("--warmup", type=int, default=1000)
    parser.add_argument("--workloads", default="point_hit,point_miss,mixed_read_update,mixed_uniform")
    parser.add_argument("--pause-seconds", type=float, default=7.0)
    parser.add_argument("--ready-timeout", type=int, default=180)
    selected = parser.parse_args(argv)
    repo = selected.repo.resolve()
    fixture = load_fixture()
    destination = fixture.require_new_directory(selected.output)
    fixture.COMMAND_LOG = destination / "control-commands.jsonl"
    fault_dir = destination / "fault"
    fault_dir.mkdir(mode=0o700)
    controls = destination / "controls"
    controls.mkdir(mode=0o700)
    for path in (Path(__file__), FIXTURE_PATH, VALIDATOR_PATH):
        shutil.copy2(path, controls / path.name)
    manifest = {
        "schema": "vibedb.read-authority-fault-qualification/1",
        "status": "preparing",
        "diagnostic_only": True,
        "timed_performance_claim": False,
        "throughput_comparison": False,
        "crdb_comparison": False,
        "runtime_image": RUNTIME,
        "environment": {
            "GOEXPERIMENT": "simd", "GOCACHE": str(GOCACHE),
            "docker_resource_limits": {"cpus": "12", "memory": "24g", "memory_swap": "24g"},
        },
        "workload": {
            "physical_nodes": 3, "groups": 4,
            "tables": fixture.table_names(4, "rf3_sql_group"),
            "workloads": [value.strip() for value in selected.workloads.split(",") if value.strip()],
            "clients": "1,8", "rows": 64,
            "operations": selected.operations, "scans": selected.scans,
            "warmup": selected.warmup, "repetitions": 1,
        },
        "fault_contract": {
            "grant_max_seconds": GRANT_SECONDS,
            "pause_seconds": selected.pause_seconds,
            "pause_is_process_signal": True,
            "pause_is_not_network_partition": True,
            "restart_quarantine_seconds": QUARANTINE_SECONDS,
            "same_volume_restart": True,
        },
        "source": {},
        "binary_sha256": {},
        "events": [],
    }
    fixture.write_json(destination / "manifest.json", manifest)
    source_before = None
    original_run = fixture.run
    original_popen = subprocess.Popen
    original_stop = fixture.stop_processes
    captured = {}
    state = {"pause": None, "pause_error": None}
    lock = threading.Lock()

    def logged_run(command, *args, **kwargs):
        values = [str(value) for value in command]
        if values[:2] == ["docker", "run"] and "--name" in values:
            with lock:
                captured["container"] = values[values.index("--name") + 1]
                captured["volume"] = values[values.index("--mount") + 1].split(",", 1)[0].split("=", 1)[1]
                manifest["container"] = captured["container"]
                manifest["volume"] = captured["volume"]
                fixture.write_json(destination / "manifest.json", manifest)
        return original_run(command, *args, **kwargs)

    def captured_popen(command, *args, **kwargs):
        values = list(command) if isinstance(command, (list, tuple)) else command
        if isinstance(values, list) and values[:2] == ["docker", "exec"]:
            if values[3:5] == ["/bench/candidate-vibedb", "cluster"]:
                with lock:
                    captured["server"] = list(values)
                    manifest["server_argv"] = list(values[3:])
                    fixture.write_json(destination / "manifest.json", manifest)
            if (len(values) > 3 and values[3] == "/bench/rf3-sqlbench" and
                    "-phase" in values and values[values.index("-phase") + 1] == "run"):
                values = list(values)
                if "-recovery-oracle" not in values:
                    values.extend(["-recovery-oracle", "/evidence/client-oracle.json"])
                with lock:
                    captured["client"] = list(values)
                    manifest["client_argv"] = list(values[3:])
                    fixture.write_json(destination / "manifest.json", manifest)
        return original_popen(values, *args, **kwargs)

    def record_event(event):
        # Keep each manifest event as an immutable checkpoint; later updates to
        # the live event dictionary must not rewrite the earlier raw record.
        manifest["events"].append(json.loads(json.dumps(event)))
        fixture.write_json(destination / "manifest.json", manifest)

    def do_pause():
        """Inject SIGSTOP/SIGCONT after a fresh fast-path observation."""
        deadline = time.monotonic() + 60
        run_dir = destination / "candidate"
        while time.monotonic() < deadline:
            with lock:
                container = captured.get("container")
            run_json = run_dir / "run.json"
            if container and run_json.exists():
                try:
                    current = json.loads(run_json.read_text())
                except (OSError, json.JSONDecodeError):
                    current = {}
                if current.get("status") == "measuring":
                    break
            time.sleep(0.1)
        else:
            state["pause_error"] = "candidate did not reach measuring state"
            return
        try:
            targets = json.loads((run_dir / "diagnostic-targets.json").read_text())
            inventory = fixture.process_inventory(container)
            fixture.save_inventory(fault_dir, inventory, "pre-pause")
            group_incarnations = node_group_incarnations(run_dir, "ready")
            record_event({
                "event": "pause-prepared", "utc": utc_now(),
                "container": container, "targets": targets,
                "process_identities": [
                    target_identity(inventory, target, group_incarnations)
                    for target in targets
                ],
            })
            prior = current_serials(fixture, container, targets, fault_dir)
            before = all_snapshots(fixture, container, targets, fault_dir,
                                   "selection-before", prior)
            time.sleep(1.5)
            prior = {node: value["serial"] for node, value in before.items()}
            after = all_snapshots(fixture, container, targets, fault_dir,
                                  "selection-after", prior)
            deltas = {
                node: counter(after[node], "authority_read_hits") -
                counter(before[node], "authority_read_hits")
                for node in before
            }
            candidates = [target for target in targets if deltas.get(target["node_id"], 0) > 0]
            # Keep the SQL endpoint's process alive where possible so the
            # client retains its session while another physical node pauses.
            endpoint_targets = [
                target for target in targets if "/node-1/" in target.get("path", "")
            ]
            non_endpoint = [target for target in candidates if target not in endpoint_targets]
            chosen = max(non_endpoint or candidates,
                         key=lambda target: deltas[target["node_id"]],
                         default=None)
            selection = {
                "basis": "recent acknowledged diagnostic authority_read_hits delta",
                "native_current_group_leader_probed": False,
                "current_holder_claim": False,
                "node_pause_only": True,
                "deltas": deltas,
                "before": before, "after": after,
                "selected": chosen,
            }
            if chosen is None:
                raise RuntimeError(
                    "no physical process recorded a recent authority fast-path hit")
            pid = str(chosen["pid"])
            pause = {
                "event": "process-pause",
                "status": "stopping",
                "utc_stop_requested": utc_now(),
                "container": container,
                "node_id": chosen["node_id"], "pid": chosen["pid"],
                "selection": selection,
                "signal_stop": ["docker", "exec", container, "kill", "-STOP", pid],
                "signal_continue": ["docker", "exec", container, "kill", "-CONT", pid],
                "grant_max_seconds": GRANT_SECONDS,
                "pause_seconds_requested": selected.pause_seconds,
                "clock_bound_note": "7 s wall pause exceeds 5 s grant, including documented 5.56 s slow-clock bound",
            }
            state["pause"] = pause
            record_event(pause)
            fixture.run(["docker", "exec", container, "kill", "-STOP", pid])
            started = time.monotonic()
            pause["utc_stop_sent"] = utc_now()
            try:
                time.sleep(selected.pause_seconds)
            finally:
                fixture.run(["docker", "exec", container, "kill", "-CONT", pid], check=False)
            elapsed = time.monotonic() - started
            pause["utc_continue_sent"] = utc_now()
            pause["pause_seconds_observed"] = elapsed
            pause["status"] = "continued"
            after_inventory = fixture.process_inventory(container)
            fixture.save_inventory(fault_dir, after_inventory, "post-pause")
            pause["post_pause_process_identity"] = target_identity(
                after_inventory, chosen, group_incarnations)
            post = all_snapshots(fixture, container, targets, fault_dir,
                                 "pause-after", current_serials(
                                     fixture, container, targets, fault_dir))
            pause["post_pause_diagnostics"] = post
            pause["unavailable_interval_seconds"] = elapsed
            pause["post_pause_counter_deltas"] = {
                node: {
                    "authority_read_hits": counter(post[node], "authority_read_hits") -
                    counter(before[node], "authority_read_hits"),
                    "authority_read_index_fallbacks": counter(post[node], "authority_read_index_fallbacks") -
                    counter(before[node], "authority_read_index_fallbacks"),
                    "read_authority_rounds_started": counter(post[node], "read_authority_rounds_started") -
                    counter(before[node], "read_authority_rounds_started"),
                }
                for node in before if node in post
            }
            pause["strict_sql_oracle_deferred_to_run"] = True
            pause["status"] = "verified-signals"
            record_event(pause)
        except BaseException as exc:
            state["pause_error"] = str(exc) or exc.__class__.__name__
            if state.get("pause") is not None:
                state["pause"]["status"] = "failed"
                state["pause"]["error"] = state["pause_error"]
                record_event(state["pause"])

    def stop_with_restart(processes, container, destination_run):
        """Retain strict pre-crash oracle, kill serving processes, restart root."""
        logs = []
        restart = {
            "event": "sigkill-restart",
            "status": "starting",
            "utc_started": utc_now(),
            "same_volume": True,
            "quarantine_seconds": QUARANTINE_SECONDS,
        }
        try:
            report = json.loads((destination_run / "report.json").read_text())
            if report.get("status") != "complete":
                raise fixture.RunnerError(
                    "SIGKILL/restart requires a fully verified pre-crash workload")
            if "client" not in captured or "server" not in captured:
                raise fixture.RunnerError("server/client argv was not captured")
            copied = fixture.run([
                "docker", "cp", container + ":/evidence/client-oracle.json",
                destination / "client-oracle.json",
            ], check=False, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            if copied.returncode:
                raise fixture.RunnerError("pre-crash recovery oracle was not retained")
            before = fixture.process_inventory(container)
            fixture.save_inventory(fault_dir, before, "pre-sigkill")
            pids = exact_candidate_pids(fixture, container, before)
            restart["killed_pids"] = pids
            restart["pre_sigkill_group_incarnations"] = node_group_incarnations(destination_run, "ready")
            restart["utc_sigkill"] = utc_now()
            restart["signal"] = "SIGKILL"
            record_event(restart)
            fixture.run(["docker", "exec", container, "kill", "-KILL", *pids])
            wait_processes(processes)
            restart["utc_processes_stopped"] = utc_now()
            log_path = destination / "restart-server.log"
            log = log_path.open("wb")
            logs.append(log)
            started = time.monotonic()
            replacement = original_popen(captured["server"], stdout=log,
                                          stderr=subprocess.STDOUT)
            processes.append(replacement)
            fixture.wait_for_marker(
                replacement, log_path,
                ["VibeDB development RF3 physical cluster ready:"],
                args.ready_timeout,
            )
            fixture.wait_for_tcp_ports(container, [5432], args.ready_timeout)
            restart["restart_ready_seconds"] = time.monotonic() - started
            restart["utc_ready"] = utc_now()
            after = fixture.process_inventory(container)
            fixture.save_inventory(fault_dir, after, "post-restart")
            restart["post_restart_group_incarnations"] = node_group_incarnations(destination_run, "ready")
            restart["marker_files"] = copy_markers(
                fixture, container, fault_dir, "post-restart", nodes=3, groups=4)
            targets = fixture.candidate_diagnostic_targets(
                destination_run, after, 3)
            fixture.write_json(fault_dir / "post-restart-diagnostic-targets.json", targets)
            early = capture_restart_diagnostics(
                fixture, container, targets, fault_dir, "quarantine-early")
            restart["quarantine_early_diagnostics"] = early
            restart["quarantine_early_elapsed_seconds"] = time.monotonic() - started
            restart["quarantine_observable"] = bool(
                restart["quarantine_early_elapsed_seconds"] < QUARANTINE_SECONDS and
                restart["marker_files"] and
                all(record.get("exit_code") == 0 and record.get("enabled") is True
                    for record in restart["marker_files"]) and
                all(counter(value, "read_authority_rounds_started") == 0 and
                    counter(value, "read_authority_grants_accepted") == 0
                    for value in early.values())
            )
            restart["quarantine_observation_basis"] = (
                "retained enabled marker plus first acknowledged diagnostic snapshot "
                "before the configured restart fence; diagnostics have no direct boolean quarantine field"
            )
            remaining = max(0.0, QUARANTINE_SECONDS - restart["quarantine_early_elapsed_seconds"] + 0.5)
            restart["quarantine_wait_seconds"] = remaining
            if remaining:
                time.sleep(remaining)
            client = list(captured["client"])
            client[client.index("-phase") + 1] = "recovery"
            client[client.index("-output") + 1] = "/evidence/recovery.json"
            if "-diagnostic-targets" in client:
                index = client.index("-diagnostic-targets")
                del client[index:index + 2]
            restart["recovery_argv"] = client[3:]
            recovery_log = (destination / "recovery.log").open("wb")
            try:
                recovery_started = time.monotonic()
                recovered = fixture.run(client, stdout=recovery_log,
                                        stderr=subprocess.STDOUT, check=False)
                restart["recovery_elapsed_seconds"] = time.monotonic() - recovery_started
            finally:
                recovery_log.close()
            copied = fixture.run([
                "docker", "cp", container + ":/evidence/recovery.json",
                destination / "recovery.json",
            ], check=False, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            if copied.returncode:
                raise fixture.RunnerError("recovery report was not retained")
            recovery_report = json.loads((destination / "recovery.json").read_text())
            restart["recovery_exit_code"] = recovered.returncode
            restart["recovery_status"] = recovery_report.get("status")
            restart["acknowledged_state_retained"] = (
                recovered.returncode == 0 and recovery_report.get("status") == "complete")
            restart["utc_recovery_complete"] = utc_now()
            final = fixture.process_inventory(container)
            fixture.save_inventory(fault_dir, final, "post-recovery")
            restart["status"] = "verified" if (
                restart["acknowledged_state_retained"] and restart["quarantine_observable"]
            ) else "incomplete-or-failed"
            record_event(restart)
        except BaseException as exc:
            restart["status"] = "failed"
            restart["error"] = str(exc) or exc.__class__.__name__
            record_event(restart)
            raise
        finally:
            for log in logs:
                log.close()
            original_stop(processes, container, destination_run)
        return []

    try:
        source_before = source_snapshot(fixture, repo, destination, "before")
        manifest["source"] = source_before
        arch = fixture.docker_architecture()
        manifest["docker_architecture"] = arch
        image = fixture.ensure_image(RUNTIME)
        manifest["runtime_image_inspection"] = image
        binaries, metadata, env = build_candidate(fixture, repo, destination, arch)
        manifest["binary_sha256"] = fixture.binary_hashes(binaries)
        manifest["build_metadata"] = metadata
        args = type("QualificationArgs", (), {})()
        args.cpus = "12"
        args.memory = "24g"
        args.runtime_image_id = image["Id"]
        args.vibedb_sql_ports = "5432"
        args.rows = 64
        args.operations = selected.operations
        args.scans = selected.scans
        args.warmup = selected.warmup
        args.repetitions = 1
        args.skew_percent = 80
        args.ready_marker = "VibeDB development cluster ready:"
        args.ready_timeout = selected.ready_timeout
        args.parent_arg = []
        args.candidate_arg = ["--read-authority"]
        args.validator_path = VALIDATOR_PATH
        tables = fixture.table_names(4, "rf3_sql_group")
        cell = {
            "id": "read-authority-fault-3n-4g",
            "kind": "distributed-read-fault-qualification",
            "physical_nodes": 3, "tables": tables,
            "workloads": selected.workloads,
            "group_distribution": "uniform", "clients": "1,8",
            "groups": 4, "endpoint_mode": "single",
        }
        run_dir = destination / "candidate"
        schema = fixture.schema_files(run_dir, tables)
        manifest["cell"] = cell
        manifest["status"] = "measuring-diagnostic-only"
        fixture.write_json(destination / "manifest.json", manifest)
        fixture.run = logged_run
        subprocess.Popen = captured_popen
        result_holder = {}

        def run_fixture():
            started = time.monotonic()
            try:
                result_holder["result"] = fixture.run_engine(
                    args, cell, "candidate", "fault-qualification", binaries,
                    run_dir, schema, arch)
            except BaseException as exc:
                result_holder["exception"] = exc
            finally:
                result_holder["wall_elapsed_seconds"] = time.monotonic() - started

        thread = threading.Thread(target=run_fixture, name="rf3-fault-fixture")
        thread.start()
        do_pause()
        thread.join()
        if "exception" in result_holder:
            raise result_holder["exception"]
        result = result_holder.get("result", {})
        manifest["result"] = result
        manifest["run_wall_elapsed_seconds"] = result_holder.get("wall_elapsed_seconds")
        manifest["diagnostic_records"] = diagnostics_summary(run_dir / "diagnostics")
        manifest["authority_proof"] = authority_proof(manifest["diagnostic_records"])
        manifest["pause"] = state.get("pause")
        manifest["pause_error"] = state.get("pause_error")
        manifest["restart"] = next((event for event in reversed(manifest["events"])
                                     if event.get("event") == "sigkill-restart"), None)
        manifest["status"] = "complete" if (
            result.get("status") == "completed" and
            result.get("client_exit_code") == 0 and
            result.get("validation", {}).get("complete") and
            state.get("pause", {}).get("status") == "verified-signals" and
            manifest.get("restart", {}).get("status") == "verified"
        ) else "incomplete-or-failed"
    except BaseException as exc:
        manifest["status"] = "incomplete-or-failed"
        manifest["failure"] = str(exc) or exc.__class__.__name__
    finally:
        fixture.run = original_run
        subprocess.Popen = original_popen
        if source_before is not None:
            try:
                source_after = source_snapshot(fixture, repo, destination, "after")
                manifest["source_after"] = source_after
                manifest["source_stable"] = (
                    source_identity(source_before) == source_identity(source_after)
                )
                if not manifest["source_stable"]:
                    manifest["status"] = "incomplete-or-failed"
                    manifest["failure"] = "source changed during qualification"
            except BaseException as exc:
                manifest["status"] = "incomplete-or-failed"
                manifest["failure"] = "could not snapshot source after qualification: " + str(exc)
        fixture.write_json(destination / "manifest.json", manifest)
    print(destination)
    print(json.dumps({
        "status": manifest.get("status"),
        "result_status": manifest.get("result", {}).get("status"),
        "validation": manifest.get("result", {}).get("validation"),
        "pause": manifest.get("pause"),
        "restart": manifest.get("restart"),
        "failure": manifest.get("failure"),
    }, sort_keys=True))
    return 0 if manifest.get("status") == "complete" else 1


if __name__ == "__main__":
    raise SystemExit(main())
