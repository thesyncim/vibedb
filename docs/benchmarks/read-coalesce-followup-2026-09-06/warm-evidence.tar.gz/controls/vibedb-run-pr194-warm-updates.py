import importlib.util,sys,json,hashlib,shutil,time,subprocess,threading,os
from pathlib import Path
sys.dont_write_bytecode=True
repo=Path('/private/tmp/vibedb-impact-final-3a144f65')
sp=importlib.util.spec_from_file_location('comparison',repo/'scripts/bench/run-distributed-read-comparison.py');c=importlib.util.module_from_spec(sp);sp.loader.exec_module(c);f=c.load_fixture()
out=Path('/private/tmp/vibedb-pr194-warm-updates');out.mkdir()
controls=out/'controls';controls.mkdir()
for p in [Path(__file__),repo/'scripts/bench/run-distributed-read-comparison.py',repo/'scripts/bench/run-fused-node-comparison.py',repo/'scripts/bench/summarize-crdb-sql.py']:shutil.copy2(p,controls/p.name)
f.COMMAND_LOG=out/'control-commands.jsonl'

# Record concurrent container activity; never stop or modify unrelated work.
owned=set(); interference=[]; stop_monitor=threading.Event()
original_run=f.run
initial=subprocess.check_output(['docker','ps','--format','{{json .}}'],text=True)
(out/'initial-containers.jsonl').write_text(initial)
for line in initial.splitlines():
 row=json.loads(line)
 if row['Names']!='vibedb-index-next-01a06d48':raise RuntimeError('non-idle container present: '+row['Names'])
events=subprocess.Popen(['docker','events','--since',str(int(time.time())),'--format','{{json .}}'],stdout=subprocess.PIPE,text=True)
def collect_events():
 with (out/'docker-events.jsonl').open('w')as log:
  for line in events.stdout:
   log.write(line);log.flush()
   e=json.loads(line);name=e.get('Actor',{}).get('Attributes',{}).get('name','');action=e.get('Action','')
   if e.get('Type')=='container' and name not in owned and (action=='start' or action.startswith('exec_start')):interference.append(e)
threading.Thread(target=collect_events,daemon=True).start()
def guarded_run(argv,**kwargs):
 if list(map(str,argv[:2]))==['docker','run'] and '--name' in argv:owned.add(str(argv[argv.index('--name')+1]))
 return original_run(argv,**kwargs)
f.run=guarded_run

selected=c.parser().parse_args([str(out),'--repo',str(repo),'--baseline-ref','38409c7a','--candidate-ref','e8cf5617','--client-source','/private/tmp/vibedb-impact-baseline-02b75683','--workloads','update_existing','--clients','1','--operations','8000','--scans','500','--warmup','8000','--repetitions','3'])
opts=c.validate_options(selected,f);args=c.make_fixture_args(selected,f,opts['workloads']);args.candidate_arg=[];args.validator_path=controls/'summarize-crdb-sql.py';args.runtime_image_id='sha256:648f440f42a0958804efb24df176f806f9d353b41f1c0627f666428e40310f6b'
cell=c.read_cells(selected,f,opts['workloads'],opts['clients'])[0]
bins={'baseline':Path('/private/tmp/vibedb-pr194-perf-baseline-bin'),'scheduler':Path('/private/tmp/vibedb-pr194-perf-candidate-bin')}
def hashes(p):return {x.name:hashlib.sha256(x.read_bytes()).hexdigest()for x in sorted(p.iterdir())if x.is_file()}
sequence=['baseline','scheduler','scheduler','baseline']
manifest={'schema':'vibedb.read-coalesce-abba/1','status':'measuring','scope':'Fixed-long-warmup update-only PR 194 ABBA follow-up; prior campaign retained separately; no authority enabled; same frozen client; container activity guarded, host activity not excluded; no CRDB performance claim','baseline':'38409c7a','scheduler':'e8cf5617','runtime_image':args.runtime_image_id,'sequence':sequence,'binary_sha256':{k:hashes(v)for k,v in bins.items()},'source_fixture_manifest':json.loads(Path('/private/tmp/vibedb-impact-matrix-final/manifest.json').read_text()),'controls_sha256':hashes(controls),'cell':cell,'operations':8000,'warmup':8000,'repetitions':3,'runs':[]}
manifest['scheduler_patch']=f.run(['git','diff','38409c7a','e8cf5617','--','internal/raftservice'],cwd=Path('/private/tmp/vibedb-review-194')).stdout.decode();f.write_json(out/'manifest.json',manifest)
for i,arm in enumerate(sequence):
 name=f'{i+1}-{arm}';path=out/name;schema=f.schema_files(path,cell['tables']);print(name,'starting',flush=True)
 start=time.time();r=f.run_engine(args,cell,'candidate',name,bins[arm],path,schema,'arm64');r.update(concurrent_container_activity=list(interference),arm=arm,start=start,end=time.time(),binary_unchanged=hashes(bins[arm])==manifest['binary_sha256'][arm]);manifest['runs'].append(r);f.write_json(out/'manifest.json',manifest);print(name,r['status'],r['errors'],flush=True)
 if r['status']!='completed' or r['errors'] or not r['binary_unchanged'] or interference:events.terminate();manifest['status']='incomplete';f.write_json(out/'manifest.json',manifest);raise SystemExit(1)
events.terminate();manifest['status']='complete';f.write_json(out/'manifest.json',manifest)
